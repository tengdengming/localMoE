#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sys
from huggingface_hub import HfApi, login

if len(sys.argv) < 2:
    print("❌ 用法: python get_file_list.py <repo_id>")
    sys.exit(1)

repo_id = sys.argv[1]

hf_token = os.environ.get("HUGGINGFACE_HUB_TOKEN")
if hf_token:
    login(token=hf_token)
    print("✅ 已使用 Hugging Face Token 认证")

api = HfApi()
files = api.list_repo_files(repo_id, repo_type="model")

with open("file_list.txt", "w") as f:
    for file in files:
        f.write(file.strip() + "\n")

print(f"📄 模型 {repo_id} 文件列表已保存至 file_list.txt，共 {len(files)} 个文件")
