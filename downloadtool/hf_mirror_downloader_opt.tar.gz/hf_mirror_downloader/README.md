# Hugging Face 模型下载工具（带国内镜像 fallback）

本工具支持通过 HuggingFace 或清华镜像下载模型，具备断点续传、自动重试、SHA256 校验等功能。

## 使用方法

```bash
# 解压并进入目录
tar -xzvf hf_mirror_downloader.tar.gz
cd hf_mirror_downloader

# 安装依赖
pip install -r requirements.txt

# 设置 huggingface token（如需访问 gated 模型）
export HUGGINGFACE_HUB_TOKEN=hf_xxxx...

# 下载模型（TUNA + fallback）
./download_hf_model.sh Qwen/Qwen3-30B-A3B
```

下载位置：`/data/models/Qwen-Qwen3-30B-A3B/`
