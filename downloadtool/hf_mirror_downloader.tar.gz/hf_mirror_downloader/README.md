# Hugging Face 镜像模型下载工具

支持通过清华镜像高速下载 Hugging Face 模型仓库中的所有文件，具备断点续传、自动重试、SHA256 哈希校验能力。

## 📦 使用方法

```bash
# 进入解压目录
cd hf_mirror_downloader

# 安装依赖（推荐虚拟环境）
pip install -r requirements.txt

# 执行脚本：传入模型 ID，例如
./download_hf_model.sh Qwen/Qwen3-30B-A3B
```

## ✅ 下载结果

下载文件将自动保存到：

```
/data/models/Qwen-Qwen3-30B-A3B/
```

支持重入、断点续传、自动重试和校验。

## 📌 依赖环境

- Python 3.8+
- `wget`, `sha256sum`
