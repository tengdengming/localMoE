#!/bin/bash

set -e

if [[ $# -lt 1 ]]; then
  echo "❌ 用法: ./download_hf_model.sh <REPO_ID> （如 Qwen/Qwen3-30B-A3B）"
  exit 1
fi

REPO_ID="$1"
REPO_ID_SAFE="${REPO_ID//\//-}"
OUT_DIR="/data/models/${REPO_ID_SAFE}"
MIRROR_PREFIX="https://mirrors.tuna.tsinghua.edu.cn/huggingface/models--${REPO_ID//\//--}/resolve/main"

# 获取文件列表
echo "📦 获取模型文件列表..."
python3 get_file_list.py "$REPO_ID"

if [[ ! -f "file_list.txt" ]]; then
  echo "❌ 缺少 file_list.txt，获取失败"
  exit 1
fi

mkdir -p "$OUT_DIR"

TOTAL=$(wc -l < file_list.txt)
COUNT=0
MAX_RETRY=5

echo "🚀 开始下载（带自动重试和哈希校验）"
while IFS= read -r file; do
  ((COUNT++))
  echo "[$COUNT/$TOTAL] 📥 正在处理: $file"

  URL="$MIRROR_PREFIX/$file"
  DEST="$OUT_DIR/$file"
  HASH_FILE="$file.sha256"
  HASH_URL="$MIRROR_PREFIX/$HASH_FILE"
  HASH_DEST="$OUT_DIR/$HASH_FILE"

  mkdir -p "$(dirname "$DEST")"

  for ((i=1; i<=MAX_RETRY; i++)); do
    wget -c --tries=3 "$URL" -O "$DEST" && break
    echo "⚠️ 第 $i 次尝试失败，重试中..."
    sleep 2
  done

  wget -q --tries=2 "$HASH_URL" -O "$HASH_DEST" || echo "❗ 未找到 hash 文件，跳过校验: $HASH_FILE"

  if [[ -f "$HASH_DEST" ]]; then
    EXPECTED_HASH=$(cut -d' ' -f1 "$HASH_DEST")
    ACTUAL_HASH=$(sha256sum "$DEST" | cut -d' ' -f1)

    if [[ "$EXPECTED_HASH" != "$ACTUAL_HASH" ]]; then
      echo "❌ 文件校验失败: $file"
      echo "Expected: $EXPECTED_HASH"
      echo "Actual  : $ACTUAL_HASH"
      exit 1
    else
      echo "✅ 校验通过"
    fi
  fi

done < file_list.txt

echo "🎉 所有文件下载并校验成功，保存在: $OUT_DIR"
