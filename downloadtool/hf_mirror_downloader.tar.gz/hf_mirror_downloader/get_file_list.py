#!/usr/bin/env python3
from huggingface_hub import HfApi
import sys

if len(sys.argv) < 2:
    print("用法: python get_file_list.py <repo_id>")
    sys.exit(1)

repo_id = sys.argv[1]
api = HfApi()
files = api.list_repo_files(repo_id, repo_type="model")

with open("file_list.txt", "w") as f:
    for file in files:
        f.write(file.strip() + "\n")

print(f"✅ 模型 {repo_id} 文件列表已写入 file_list.txt，数量: {len(files)}")
